# Naam Proefopdracht
*Let goed bij het maken, schrijven en bijhouden van dit document op de **[prestatie-indicatoren](https://drive.google.com/drive/folders/1y8l0Zr4E8b6gYJui_pSzQaoWr-gEr6JN?usp=sharing)**. Deze toon je aan in dit document.*

Hier komt een korte beschrijving van de proefopdracht. Wat heb je precies gedaan? 

## Features
Wanneer je een specifiek onderdeel wilt uitlichten kun je dat in deze sectie benoemen.

- [Awesome Algoritme](link)
- [Specifieke Mechanic](link)
- [Iets unieks waar je trots op bent binnen de project](link)

## Software Anaylse 
Welke software heb je voor deze proefopdracht onderzocht? En waarom heb je uiteindelijk gekozen voor de gekozen Software. Benoem hier specifieke argumenten.

## Leerdoelen 
Wat wil je bereiken met dit project? Formuleer dit kort, krachtig en haalbaar.
- Het Flood-Fill algoritme snappen en toepassen
- Het ontwikkelen van een generieke FSM.
- etc. etc.

## Planning 
Je hebt grofweg 2 weken, hoe deel je deze twee weken in. Wat plan je wanneer om precies te doen?

| | maandag | dinsdag | woensdag | donderdag | vrijdag |
| --- | --- | --- | --- | --- | --- |
|week 1 |
|week 2 |

## Bronnen
Welke bronnen heb je gebruikt? Zowel youtube filmpjes als artikelen

- [The Guide To Game Design](link)
- [Alleatoric Algorithms](link)
- [Flood-Fill Wikipedia](link)
